describe('Passing Test for CI Success', () => {
    it('should pass to demonstrate CI success scenario', () => {
        // This test will pass
        expect(true).toBe(true);
    });

    it('should correctly add numbers', () => {
        expect(1 + 1).toBe(2);
    });
});
